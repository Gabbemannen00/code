#include <iostream>
#include <vector> //för att kunna skapa vector och använda det.
#include <limits> //för att köra felhantering av input.
#include <algorithm> //för att kunna sortera nummer.


/*Uppgift 1 (G - 10 poäng)

Skriv ett program som läser in heltal från användaren tills de matar in 0. 
Programmet ska:
 - Lagra talen i en vektor 
 - Beräkna och visa:  
     * Produkten av alla positiva tal  
     * Antalet jämna respektive udda tal  
    * Det näst största talet i inmatningen*/

   

int main(){

    std :: string restart; //Variabel som tar in en sträng från användaren, syfte är att kunna starta om programmet när programmet är slut.
    
    //Börjar med att skriva en kod som ska bygga upp vektorn med nummer i som läggs till av användaren.
    do{
    std :: vector<int>numbers; //skapar en vektor som kommer lagra heltal som matas in av användaren.
    int user_input; //skapar en heltals variabel som ska ta in användarens svar.
    std :: cout<< "Skriv en serie med tal, skriv talet 0 när som helst för att sluta med tillägningen av tal."<< std :: endl;
    while (true){//kör denna loop så länge det är sant.
        std :: cout<<"Skriv ett heltal: ";
        std :: cin >> user_input; //tar in användarens svar.
        //Kollar först om användaren matar in något annat än ett nummer.
        if(std :: cin.fail()){//om ett fel skulle upptäckas kör:
           std :: cin.clear();//rensa error flaggorna för att göra cin funktionen tillgänglig igen.
           std :: cin.ignore(std :: numeric_limits<std :: streamsize>::max(), '\n'); //rensar den felaktiga inmatningen från bufferten.
           std :: cout <<"fel! Du kan bara mata in heltal.\n"; //felmeddelande för användaren, så hen vet att hen skrev fel.
           continue; //startar om loopen.
        }

        if (user_input == 0){ //om användaren skriver 0, slutar vi lägga till tal i vektorn.
            break;
        }
        std :: cout<<"Talet "<<user_input<<" lades till i talserien!"<<std :: endl;
        numbers.push_back(user_input); //Om svaret var giltigt läggs talet till i början av vektorn.

    } //Kollar om vektorn ens fick i sig tal efter input '0' gjorts av användaren.
    if (numbers.empty()){ //om villkoret empty är sant kommer ett felmeddelande skrivas ut.
        std :: cout << "\n";
        std :: cout << "Fel vid inmatningen har lett till stängning av program, orsak: inga tal identifierades efter inputen av '0' gjorts....\n";
        std :: cout << "\n";
        break;
    }
    else {
    std :: cout << "Dem här talen i följande ordning skrev du: "<<std :: endl;
    //går igenom alla nummer i vektorn och 
    for (int number:numbers){ //variablen number tar in och lagrar talen som finns i variabeln numbers och skriver ut dem. 
        std ::cout<<number<<", "; //Skriver ut talen en för en så de hamnar bredvid varanndra.
    }

    }
    std :: cout <<""<<std :: endl;

    //Tar reda på produkten av alla positiva tal i vektorn:

    int product = 1; //produkten får startvärdet 1.

    for(int numr : numbers){
        if (numr > 0){ //tar alla nummer som är större än 0.
            product *=numr; //räknar ut produkten av alla jämna nummer genom att multiplicera dem med varanndra.
        }
    }

    std :: cout <<""<<std :: endl;

    std :: cout <<"Produkten av alla jämna nummer i talserien: "<<product<< std :: endl;

    std :: cout <<""<<std :: endl;

    //Går igenom och skriva ut antalet vektorns udda och jämna nummer.

    int count_evens = 0; //lagrar antalet jämna nummer.

    int count_odds = 0; //lagrar antalet udda nummer.

    //Lagrar jämna och udda tal i varsinna vektorer.

    std :: vector<int> evens; //vektor för att samla in alla jämna nummer i.
    
    std :: vector<int> odds; //vektor för att samla in alla udda nummer i.


    for(int num : numbers){//går igenom varje enskilt nummer i vektorn 'numbers'.
        if(num % 2 == 0){ //kollar om nummret är jämnt:
            evens.push_back(num); //om det stämmer lagra det i början av vektorn 'evens'.
            count_evens++; //ge variabeln +1 för varje funnet jämnt nummer.
        }
        else{
            odds.push_back(num); //alla andra nummer räknas som udda, lagra dem i vektorn 'odds'.
            count_odds++; //ge variabeln +1 för varje funnet udda nummer.
        }

    }

    std :: cout<<"Antalet jämna nummer i talserien: "<<count_evens<<std :: endl;

    std :: cout <<""<<std :: endl;

    std :: cout<<"Antalet udda nummer i talserien: "<<count_odds<<std :: endl;

    //För att beräkna vad det näst största talet är i vektorn numbers, sorterar dem först i storleksordning.

    std :: sort(numbers.begin(), numbers.end()); //Sorterar vektorn så minsta talet hamnar först och största sist.
    
    std :: cout <<""<<std :: endl;
    
    //För att komma åt det näst största talet använder jag mig utav indexet i numbers och tar med hela storleken, näst sista nummret ligger på index -2.

    std :: cout <<"Det näst största talet i talserien är: "<<numbers[numbers.size()-2] <<std :: endl;
    std :: cout <<""<<std :: endl;
    //Funktion för att starta om programmet om man vill det.

    std :: cout <<"Köra programmet igen? ja eller nej?: ";
    std :: cin >> restart; //tar in användarens svar 'ja' eller 'nej'.
    //För att slippa oroa mig över att användaren matar in svaret 'ja' på andra sätt och som kan orsaka fel vid omstarten så kan jag med hjälp
    // av funktionen std::transform. 
    std ::transform(restart.begin(), restart.end(), restart.begin(), :: tolower); //omvandlar användarens svar till små bokstäver.
    //Förklaring av argumenten: transform(sträng.startposition, sträng.slutposition, destinationen för sträng.slutposition)
    std :: cout <<"\n";

}while (restart == "ja"); //kör denna do while loop så länge användaren svarar ja i små bokstäver.
    
return 0;

}

